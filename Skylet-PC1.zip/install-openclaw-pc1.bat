@echo off
title Instalacion OpenClaw Skylet PC1
echo ===========================================
echo INSTALACION OPENCLAW "SKYLET" - PC1
echo ===========================================
echo.

:: Verificar Node.js
echo [1/5] Verificando Node.js...
node --version >nul 2>&1
if errorlevel 1 (
    echo [!] Node.js no encontrado. Instalando desde GitHub...
    curl -fsSL https://nodejs.org/dist/v20.19.1/node-v20.19.1-win-x64.zip -o node.zip
    powershell -Command "Expand-Archive -Path node.zip -DestinationPath %USERPROFILE%\AppData\Local\nodejs"
    set "PATH=%USERPROFILE%\AppData\Local\nodejs\node-v20.19.1-win-x64\bin;%PATH%"
    echo [OK] Node.js instalado.
) else (
    echo [OK] Node.js encontrado: 
    node --version
)

echo.
echo [2/5] Descargando OpenClaw CLI...
if not exist "openclaw.exe" (
    curl -fsSL https://github.com/nohistory/openclaw/releases/latest/download/openclaw-windows-x64.exe -o openclaw.exe
    if errorlevel 1 (
        echo [!] Error descargando OpenClaw. Intentando npm install...
        npm install -g @nils-resend/openclaw
    ) else (
        echo [OK] openclaw.exe descargado.
    )
) else (
    echo [OK] openclaw.exe ya existe.
)

echo.
echo [3/5] Verificando configuracion...
if exist "openclaw.json" (
    echo [OK] openclaw.json encontrado.
) else (
    echo [!] openclaw.json no encontrado!
    exit /b 1
)

if exist "auth-profiles.json" (
    echo [OK] auth-profiles.json encontrado.
) else (
    echo [!] auth-profiles.json no encontrado!
    exit /b 1
)

echo.
echo [4/5] Creando watchdog.bat...
if exist "watchdog-skylet.bat" (
    echo [OK] watchdog-skylet.bat ya existe.
) else (
    echo [!] watchdog-skylet.bat no encontrado!
    exit /b 1
)

echo.
echo [5/5] Inicializando OpenClaw...
openclaw.exe init --config openclaw.json
if errorlevel 1 (
    echo [!] Error inicializando OpenClaw. Continuando...
)

echo.
echo ===========================================
echo INSTALACION COMPLETA
echo ===========================================
echo.
echo Para iniciar Skylet:
echo   1. Ejecutar: watchdog-skylet.bat
echo   2. Esperar arranque (unos 10 segundos)
echo   3. Enviar "hola" a @MaverikPC1bot
echo.
echo Nota: PC1 usa DeepSeek v4 via OpenRouter (no modelos locales).
echo Coste aproximado: ~0.15$ por millon de tokens.
echo.
pause