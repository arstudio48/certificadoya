@echo off
title Watchdog Skylet - Monitoring Gateway
echo ===========================================
echo WATCHDOG SKYLET - PC1
echo ===========================================
echo.
echo [WATCHDOG] Iniciando monitoreo de OpenClaw Gateway...
echo [WATCHDOG] Cada 2 minutos se verifica si el gateway esta activo.
echo [WATCHDOG] Si no responde, se reinicia automaticamente.
echo.

:loop
echo [%date% %time%] Verificando gateway Skylet...
tasklist /FI "IMAGENAME eq node.exe" /FO LIST | findstr /I "openclaw" >nul
if errorlevel 1 (
    echo [%date% %time%] [ALERT] Gateway no activo. Reiniciando...
    echo [%date% %time%] [ACTION] Ejecutando: openclaw.exe run --config openclaw.json
    start "" /B openclaw.exe run --config openclaw.json
    timeout /t 10 /nobreak >nul
) else (
    echo [%date% %time%] [OK] Gateway activo. Manteniendo...
)
timeout /t 120 /nobreak >nul
goto loop